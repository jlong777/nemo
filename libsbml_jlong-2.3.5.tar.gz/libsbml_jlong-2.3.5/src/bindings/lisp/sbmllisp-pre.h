# 1 "sbmllisp.h"
# 1 "<built-in>"
# 1 "<command line>"
# 1 "sbmllisp.h"
# 38 "sbmllisp.h"
typedef struct
{
  int dummy;
} FILE;






# 1 "../../sbml/SBMLConvert.h" 1
# 56 "../../sbml/SBMLConvert.h"
# 1 "../../sbml/SBase.h" 1
# 56 "../../sbml/SBase.h"
# 1 "../../common/libsbml-config.h" 1
# 59 "../../common/libsbml-config.h"
# 1 "../../common/libsbml-config-unix.h" 1
# 60 "../../common/libsbml-config.h" 2
# 57 "../../sbml/SBase.h" 2
# 1 "../../common/extern.h" 1
# 58 "../../sbml/SBase.h" 2
# 188 "../../sbml/SBase.h"



# 1 "../../common/sbmlfwd.h" 1
# 56 "../../common/sbmlfwd.h"
# 1 "../../common/libsbml-config.h" 1
# 57 "../../common/sbmlfwd.h" 2
# 75 "../../common/sbmlfwd.h"
typedef struct SBase SBase_t;
typedef struct SBMLDocument SBMLDocument_t;
typedef struct Model Model_t;

typedef struct FunctionDefinition FunctionDefinition_t;
typedef struct Unit Unit_t;
typedef struct UnitDefinition UnitDefinition_t;
typedef struct Compartment Compartment_t;
typedef struct Species Species_t;
typedef struct Parameter Parameter_t;

typedef struct Rule Rule_t;
typedef struct AssignmentRule AssignmentRule_t;
typedef struct AlgebraicRule AlgebraicRule_t;
typedef struct RateRule RateRule_t;
typedef struct CompartmentVolumeRule CompartmentVolumeRule_t;
typedef struct ParameterRule ParameterRule_t;
typedef struct SpeciesConcentrationRule SpeciesConcentrationRule_t;

typedef struct Reaction Reaction_t;
typedef struct KineticLaw KineticLaw_t;
typedef struct SimpleSpeciesReference SimpleSpeciesReference_t;
typedef struct ModifierSpeciesReference ModifierSpeciesReference_t;
typedef struct SpeciesReference SpeciesReference_t;

typedef struct Event Event_t;
typedef struct EventAssignment EventAssignment_t;

typedef struct SBMLReader SBMLReader_t;
typedef struct SBMLWriter SBMLWriter_t;

typedef struct MathMLDocument MathMLDocument_t;
typedef struct MathMLReader MathMLReader_t;
typedef struct MathMLWriter MathMLWriter_t;

typedef struct ASTNode ASTNode_t;
typedef struct List List_t;
typedef struct ListOf ListOf_t;
typedef struct ParseMessage ParseMessage_t;
# 192 "../../sbml/SBase.h" 2
# 1 "../../sbml/SBMLTypeCodes.h" 1
# 60 "../../sbml/SBMLTypeCodes.h"







typedef enum
{
    SBML_UNKNOWN

  , SBML_COMPARTMENT
  , SBML_DOCUMENT
  , SBML_EVENT
  , SBML_EVENT_ASSIGNMENT
  , SBML_FUNCTION_DEFINITION
  , SBML_KINETIC_LAW
  , SBML_LIST_OF
  , SBML_MODEL
  , SBML_PARAMETER
  , SBML_REACTION
  , SBML_SPECIES
  , SBML_SPECIES_REFERENCE
  , SBML_MODIFIER_SPECIES_REFERENCE
  , SBML_UNIT_DEFINITION
  , SBML_UNIT
  , SBML_ALGEBRAIC_RULE
  , SBML_ASSIGNMENT_RULE
  , SBML_RATE_RULE
  , SBML_SPECIES_CONCENTRATION_RULE
  , SBML_COMPARTMENT_VOLUME_RULE
  , SBML_PARAMETER_RULE
# 109 "../../sbml/SBMLTypeCodes.h"
} SBMLTypeCode_t;








const char *
SBMLTypeCode_toString (SBMLTypeCode_t tc);



# 193 "../../sbml/SBase.h" 2
# 201 "../../sbml/SBase.h"

void
SBase_init (SBase_t *sb, SBMLTypeCode_t tc);





void
SBase_clear (SBase_t *sb);






SBMLTypeCode_t
SBase_getTypeCode (const SBase_t *sb);





unsigned int
SBase_getColumn (const SBase_t *sb);





unsigned int
SBase_getLine (const SBase_t *sb);





const char *
SBase_getMetaId (const SBase_t *sb);





const char *
SBase_getNotes (const SBase_t *sb);





const char *
SBase_getAnnotation (const SBase_t *sb);





int
SBase_isSetMetaId (const SBase_t *sb);





int
SBase_isSetNotes (const SBase_t *sb);






int
SBase_isSetAnnotation (const SBase_t *sb);








void
SBase_setMetaId (SBase_t *sb, const char *metaid);







void
SBase_setNotes (SBase_t *sb, const char *notes);







void
SBase_setAnnotation (SBase_t *sb, const char *annotation);







void
SBase_unsetMetaId (SBase_t *sb);






void
SBase_unsetNotes (SBase_t *sb);






void
SBase_unsetAnnotation (SBase_t *sb);



# 57 "../../sbml/SBMLConvert.h" 2
# 1 "../../sbml/Model.h" 1
# 783 "../../sbml/Model.h"

# 792 "../../sbml/Model.h"

Model_t *
Model_create (void);








Model_t *
Model_createWith (const char *sid);








Model_t *
Model_createWithName (const char *string);





void
Model_free (Model_t *m);






const char *
Model_getId (const Model_t *m);





const char *
Model_getName (const Model_t *m);






int
Model_isSetId (const Model_t *m);





int
Model_isSetName (const Model_t *m);
# 863 "../../sbml/Model.h"

void
Model_moveAllIdsToNames (Model_t *m);
# 876 "../../sbml/Model.h"

void
Model_moveAllNamesToIds (Model_t *m);






void
Model_moveIdToName (Model_t *m);






void
Model_moveNameToId (Model_t *m);






void
Model_setId (Model_t *m, const char *sid);





void
Model_setName (Model_t *m, const char *string);







void
Model_unsetId (Model_t *m);






void
Model_unsetName (Model_t *m);
# 935 "../../sbml/Model.h"

FunctionDefinition_t *
Model_createFunctionDefinition (Model_t *m);








UnitDefinition_t *
Model_createUnitDefinition (Model_t *m);
# 956 "../../sbml/Model.h"

Unit_t *
Model_createUnit (Model_t *m);








Compartment_t *
Model_createCompartment (Model_t *m);








Species_t *
Model_createSpecies (Model_t *m);








Parameter_t *
Model_createParameter (Model_t *m);
# 998 "../../sbml/Model.h"

AssignmentRule_t *
Model_createAssignmentRule (Model_t *m);
# 1010 "../../sbml/Model.h"

RateRule_t *
Model_createRateRule (Model_t *m);








AlgebraicRule_t *
Model_createAlgebraicRule (Model_t *m);








CompartmentVolumeRule_t *
Model_createCompartmentVolumeRule (Model_t *m);








ParameterRule_t *
Model_createParameterRule (Model_t *m);








SpeciesConcentrationRule_t *
Model_createSpeciesConcentrationRule (Model_t *m);








Reaction_t *
Model_createReaction (Model_t *m);
# 1072 "../../sbml/Model.h"

SpeciesReference_t *
Model_createReactant (Model_t *m);
# 1084 "../../sbml/Model.h"

SpeciesReference_t *
Model_createProduct (Model_t *m);
# 1096 "../../sbml/Model.h"

ModifierSpeciesReference_t *
Model_createModifier (Model_t *m);
# 1108 "../../sbml/Model.h"

KineticLaw_t *
Model_createKineticLaw (Model_t *m);
# 1120 "../../sbml/Model.h"

Parameter_t *
Model_createKineticLawParameter (Model_t *m);








Event_t *
Model_createEvent (Model_t *m);
# 1141 "../../sbml/Model.h"

EventAssignment_t *
Model_createEventAssignment (Model_t *m);






void
Model_addFunctionDefinition (Model_t *m, FunctionDefinition_t *fd);





void
Model_addUnitDefinition (Model_t *m, UnitDefinition_t *ud);





void
Model_addCompartment (Model_t *m, Compartment_t *c);





void
Model_addSpecies (Model_t *m, Species_t *s);





void
Model_addParameter (Model_t *m, Parameter_t *p);





void
Model_addRule (Model_t *m, Rule_t *r);





void
Model_addReaction (Model_t *m, Reaction_t *r);





void
Model_addEvent (Model_t *m, Event_t *e);






ListOf_t *
Model_getListOfFunctionDefinitions (Model_t *m);





ListOf_t *
Model_getListOfUnitDefinitions (Model_t *m);





ListOf_t *
Model_getListOfCompartments (Model_t *m);





ListOf_t *
Model_getListOfSpecies (Model_t *m);





ListOf_t *
Model_getListOfParameters (Model_t *m);





ListOf_t *
Model_getListOfRules (Model_t *m);





ListOf_t *
Model_getListOfReactions (Model_t *m);





ListOf_t *
Model_getListOfEvents (Model_t *m);






ListOf_t *
Model_getListOfByTypecode (Model_t *m, SBMLTypeCode_t type);





FunctionDefinition_t *
Model_getFunctionDefinition (const Model_t *m, unsigned int n);






FunctionDefinition_t *
Model_getFunctionDefinitionById (const Model_t *m, const char *sid);





UnitDefinition_t *
Model_getUnitDefinition (const Model_t *m, unsigned int n);






UnitDefinition_t *
Model_getUnitDefinitionById (const Model_t *m, const char *sid);





Compartment_t *
Model_getCompartment (const Model_t *m, unsigned int n);






Compartment_t *
Model_getCompartmentById (const Model_t *m, const char *sid);





Species_t *
Model_getSpecies (const Model_t *m, unsigned int n);






Species_t *
Model_getSpeciesById (const Model_t *m, const char *sid);





Parameter_t *
Model_getParameter (const Model_t *m, unsigned int n);






Parameter_t *
Model_getParameterById (const Model_t *m, const char *sid);





Rule_t *
Model_getRule (const Model_t *m, unsigned int n);





Reaction_t *
Model_getReaction (const Model_t *m, unsigned int n);






Reaction_t *
Model_getReactionById (const Model_t *m, const char *sid);





Event_t *
Model_getEvent (const Model_t *m, unsigned int n);






Event_t *
Model_getEventById (const Model_t *m, const char *sid);






unsigned int
Model_getNumFunctionDefinitions (const Model_t *m);





unsigned int
Model_getNumUnitDefinitions (const Model_t *m);





unsigned int
Model_getNumCompartments (const Model_t *m);





unsigned int
Model_getNumSpecies (const Model_t *m);






unsigned int
Model_getNumSpeciesWithBoundaryCondition (const Model_t *m);






unsigned int
Model_getNumParameters (const Model_t *m);





unsigned int
Model_getNumRules (const Model_t *m);





unsigned int
Model_getNumReactions (const Model_t *m);





unsigned int
Model_getNumEvents (const Model_t *m);
# 1484 "../../sbml/Model.h"

# 58 "../../sbml/SBMLConvert.h" 2
# 1 "../../sbml/Reaction.h" 1
# 386 "../../sbml/Reaction.h"

# 395 "../../sbml/Reaction.h"

Reaction_t *
Reaction_create (void);
# 407 "../../sbml/Reaction.h"

Reaction_t *
Reaction_createWith ( const char *sid,
                      KineticLaw_t *kl,
                      int reversible,
                      int fast );





void
Reaction_free (Reaction_t *r);








void
Reaction_initDefaults (Reaction_t *r);






const char *
Reaction_getId (const Reaction_t *r);





const char *
Reaction_getName (const Reaction_t *r);





KineticLaw_t *
Reaction_getKineticLaw (const Reaction_t *r);





int
Reaction_getReversible (const Reaction_t *r);





int
Reaction_getFast (const Reaction_t *r);






int
Reaction_isSetId (const Reaction_t *r);








int
Reaction_isSetName (const Reaction_t *r);





int
Reaction_isSetKineticLaw (const Reaction_t *r);
# 499 "../../sbml/Reaction.h"

int
Reaction_isSetFast (const Reaction_t *r);







void
Reaction_moveIdToName (Reaction_t *r);






void
Reaction_moveNameToId (Reaction_t *r);






void
Reaction_setId (Reaction_t *r, const char *sid);





void
Reaction_setName (Reaction_t *r, const char *string);





void
Reaction_setKineticLaw (Reaction_t *r, KineticLaw_t *kl);





void
Reaction_setReversible (Reaction_t *r, int value);





void
Reaction_setFast (Reaction_t *r, int value);






ListOf_t *
Reaction_getListOfReactants (Reaction_t *r);





ListOf_t *
Reaction_getListOfProducts (Reaction_t *r);





ListOf_t *
Reaction_getListOfModifiers (Reaction_t *r);






void
Reaction_addReactant (Reaction_t *r, SpeciesReference_t *sr);





void
Reaction_addProduct (Reaction_t *r, SpeciesReference_t *sr);





void
Reaction_addModifier (Reaction_t *r, ModifierSpeciesReference_t *msr);






SpeciesReference_t *
Reaction_getReactant (const Reaction_t *r, unsigned int n);






SpeciesReference_t *
Reaction_getReactantById (const Reaction_t *r, const char *sid);





SpeciesReference_t *
Reaction_getProduct (const Reaction_t *r, unsigned int n);






SpeciesReference_t *
Reaction_getProductById (const Reaction_t *r, const char *sid);





ModifierSpeciesReference_t *
Reaction_getModifier (const Reaction_t *r, unsigned int n);






ModifierSpeciesReference_t *
Reaction_getModifierById (const Reaction_t *r, const char *sid);






unsigned int
Reaction_getNumReactants (const Reaction_t *r);





unsigned int
Reaction_getNumProducts (const Reaction_t *r);






unsigned int
Reaction_getNumModifiers (const Reaction_t *r);
# 677 "../../sbml/Reaction.h"

void
Reaction_unsetName (Reaction_t *r);






void
Reaction_unsetKineticLaw (Reaction_t *r);
# 696 "../../sbml/Reaction.h"

void
Reaction_unsetFast (Reaction_t *r);
# 708 "../../sbml/Reaction.h"

int
ReactionIdCmp (const char *sid, const Reaction_t *r);



# 59 "../../sbml/SBMLConvert.h" 2



# 70 "../../sbml/SBMLConvert.h"
void

SBML_convertToL2 (Model_t *m, SBase_t *sb);






void

SBML_convertNameToId (SBase_t *sb);
# 96 "../../sbml/SBMLConvert.h"
void
SBML_convertReactionsInModelToL2 (Model_t *m);
# 111 "../../sbml/SBMLConvert.h"

void
SBML_addModifiersToReaction (Reaction_t *r, const Model_t *m);






void
SBML_convertRuleToL2 (Model_t *m, Rule_t *r);




void

SBML_convertModelToL1 (Model_t *m, SBase_t *sb);







void

SBML_convertToL1 (Model_t *m, SBase_t *sb);






void

SBML_convertIdToName (SBase_t *sb);






void

SBML_includeCompartment (Model_t *m);







void

SBML_convertAllSpeciesToL1 (Model_t *m);






void
SBML_convertSpeciesToL1 (Model_t *m, Species_t *s);
# 187 "../../sbml/SBMLConvert.h"
void
SBML_convertReactionsInModelToL1 (Model_t *m);
# 197 "../../sbml/SBMLConvert.h"
void
SBML_convertStoichiometryToL1 (SpeciesReference_t *sr);






void

SBML_convertAllRulesToL1 (Model_t *m);





void

SBML_applyFunctionDefinitions (Model_t *m);


# 49 "sbmllisp.h" 2
# 1 "../../sbml/SBMLReader.h" 1
# 57 "../../sbml/SBMLReader.h"
# 1 "../../xml/XMLSchemaValidation.h" 1
# 72 "../../xml/XMLSchemaValidation.h"
typedef enum
{
    XML_SCHEMA_VALIDATION_NONE
  , XML_SCHEMA_VALIDATION_BASIC
  , XML_SCHEMA_VALIDATION_FULL
} XMLSchemaValidation_t;
# 58 "../../sbml/SBMLReader.h" 2







typedef enum
{
    SBML_READ_ERROR_UNKNOWN = 0
  , SBML_READ_ERROR_FILE_NOT_FOUND = 1
  , SBML_READ_ERROR_NOT_SBML = 2
} SBMLReadError_t;
# 234 "../../sbml/SBMLReader.h"

# 249 "../../sbml/SBMLReader.h"

SBMLReader_t *
SBMLReader_create (void);





void
SBMLReader_free (SBMLReader_t *sr);







const char *
SBMLReader_getSchemaFilenameL1v1 (const SBMLReader_t *sr);






const char *
SBMLReader_getSchemaFilenameL1v2 (const SBMLReader_t *sr);






const char *
SBMLReader_getSchemaFilenameL2v1 (const SBMLReader_t *sr);





XMLSchemaValidation_t
SBMLReader_getSchemaValidationLevel(const SBMLReader_t *sr);
# 319 "../../sbml/SBMLReader.h"

SBMLDocument_t *
SBMLReader_readSBML (SBMLReader_t *sr, const char *filename);
# 337 "../../sbml/SBMLReader.h"

SBMLDocument_t *
SBMLReader_readSBMLFromString (SBMLReader_t *sr, const char *xml);
# 348 "../../sbml/SBMLReader.h"

void
SBMLReader_setSchemaFilenameL1v1 (SBMLReader_t *sr, const char *filename);
# 359 "../../sbml/SBMLReader.h"

void
SBMLReader_setSchemaFilenameL1v2 (SBMLReader_t *sr, const char *filename);
# 370 "../../sbml/SBMLReader.h"

void
SBMLReader_setSchemaFilenameL2v1 (SBMLReader_t *sr, const char *filename);
# 392 "../../sbml/SBMLReader.h"

void
SBMLReader_setSchemaValidationLevel ( SBMLReader_t *sr,
                                      XMLSchemaValidation_t level );
# 419 "../../sbml/SBMLReader.h"

SBMLDocument_t *
readSBML (const char *filename);
# 437 "../../sbml/SBMLReader.h"

SBMLDocument_t *
readSBMLFromString (const char *xml);



# 50 "sbmllisp.h" 2
# 1 "../../sbml/SBMLWriter.h" 1
# 151 "../../sbml/SBMLWriter.h"

# 166 "../../sbml/SBMLWriter.h"

SBMLWriter_t *
SBMLWriter_create (void);





void
SBMLWriter_free (SBMLWriter_t *sw);
# 186 "../../sbml/SBMLWriter.h"

void
SBMLWriter_setProgramName (SBMLWriter_t *sw, const char *name);
# 199 "../../sbml/SBMLWriter.h"

void
SBMLWriter_setProgramVersion (SBMLWriter_t *sw, const char *version);








int
SBMLWriter_writeSBML ( SBMLWriter_t *sw,
                       const SBMLDocument_t *d,
                       const char *filename );
# 223 "../../sbml/SBMLWriter.h"

char *
SBMLWriter_writeSBMLToString (SBMLWriter_t *sw, const SBMLDocument_t *d);
# 240 "../../sbml/SBMLWriter.h"

int
writeSBML (const SBMLDocument_t *d, const char *filename);
# 255 "../../sbml/SBMLWriter.h"

char *
writeSBMLToString (const SBMLDocument_t *d);



# 51 "sbmllisp.h" 2
# 1 "../../math/FormulaParser.h" 1
# 56 "../../math/FormulaParser.h"
# 1 "../../math/../common/extern.h" 1
# 57 "../../math/FormulaParser.h" 2
# 1 "../../math/../util/Stack.h" 1
# 61 "../../math/../util/Stack.h"
typedef struct
{
  long sp;
  long capacity;
  void **stack;
} Stack_t;






Stack_t *
Stack_create (int capacity);
# 83 "../../math/../util/Stack.h"

void
Stack_free (Stack_t *s);
# 95 "../../math/../util/Stack.h"

int
Stack_find (Stack_t *s, void *item);





void
Stack_push (Stack_t *s, void *item);





void *
Stack_pop (Stack_t *s);
# 120 "../../math/../util/Stack.h"
void *
Stack_popN (Stack_t *s, unsigned int n);





void *
Stack_peek (Stack_t *s);







void *
Stack_peekAt (Stack_t *s, int n);





int
Stack_size (Stack_t *s);






int
Stack_capacity (Stack_t *s);
# 58 "../../math/FormulaParser.h" 2

# 1 "../../math/ASTNode.h" 1
# 57 "../../math/ASTNode.h"
# 1 "../../math/../common/sbmlfwd.h" 1
# 58 "../../math/ASTNode.h" 2

# 1 "../../math/FormulaTokenizer.h" 1
# 59 "../../math/FormulaTokenizer.h"







typedef struct
{
  char *formula;
  unsigned int pos;
} FormulaTokenizer_t;





typedef enum
{
    TT_PLUS = '+'
  , TT_MINUS = '-'
  , TT_TIMES = '*'
  , TT_DIVIDE = '/'
  , TT_POWER = '^'
  , TT_LPAREN = '('
  , TT_RPAREN = ')'
  , TT_COMMA = ','
  , TT_END = '\0'
  , TT_NAME = 256
  , TT_INTEGER
  , TT_REAL
  , TT_REAL_E
  , TT_UNKNOWN
} TokenType_t;
# 120 "../../math/FormulaTokenizer.h"
typedef struct
{
  TokenType_t type;

  union
  {
    char ch;
    char *name;
    long integer;
    double real;
  } value;

  long exponent;

} Token_t;







FormulaTokenizer_t *
FormulaTokenizer_create (const char *formula);





void
FormulaTokenizer_free (FormulaTokenizer_t *ft);






Token_t *
FormulaTokenizer_nextToken (FormulaTokenizer_t *ft);





Token_t *
Token_create (void);





void
Token_free (Token_t *t);







long
Token_getInteger (const Token_t *t);






double
Token_getReal (const Token_t *t);





void
Token_negateValue (Token_t *t);



# 60 "../../math/ASTNode.h" 2
# 1 "../../math/ASTNodeType.h" 1
# 61 "../../math/ASTNodeType.h"
typedef enum
{
    AST_PLUS = '+'
  , AST_MINUS = '-'
  , AST_TIMES = '*'
  , AST_DIVIDE = '/'
  , AST_POWER = '^'

  , AST_INTEGER = 256
  , AST_REAL
  , AST_REAL_E
  , AST_RATIONAL

  , AST_NAME
  , AST_NAME_TIME

  , AST_CONSTANT_E
  , AST_CONSTANT_FALSE
  , AST_CONSTANT_PI
  , AST_CONSTANT_TRUE

  , AST_LAMBDA

  , AST_FUNCTION
  , AST_FUNCTION_ABS
  , AST_FUNCTION_ARCCOS
  , AST_FUNCTION_ARCCOSH
  , AST_FUNCTION_ARCCOT
  , AST_FUNCTION_ARCCOTH
  , AST_FUNCTION_ARCCSC
  , AST_FUNCTION_ARCCSCH
  , AST_FUNCTION_ARCSEC
  , AST_FUNCTION_ARCSECH
  , AST_FUNCTION_ARCSIN
  , AST_FUNCTION_ARCSINH
  , AST_FUNCTION_ARCTAN
  , AST_FUNCTION_ARCTANH
  , AST_FUNCTION_CEILING
  , AST_FUNCTION_COS
  , AST_FUNCTION_COSH
  , AST_FUNCTION_COT
  , AST_FUNCTION_COTH
  , AST_FUNCTION_CSC
  , AST_FUNCTION_CSCH
  , AST_FUNCTION_DELAY
  , AST_FUNCTION_EXP
  , AST_FUNCTION_FACTORIAL
  , AST_FUNCTION_FLOOR
  , AST_FUNCTION_LN
  , AST_FUNCTION_LOG
  , AST_FUNCTION_PIECEWISE
  , AST_FUNCTION_POWER
  , AST_FUNCTION_ROOT
  , AST_FUNCTION_SEC
  , AST_FUNCTION_SECH
  , AST_FUNCTION_SIN
  , AST_FUNCTION_SINH
  , AST_FUNCTION_TAN
  , AST_FUNCTION_TANH

  , AST_LOGICAL_AND
  , AST_LOGICAL_NOT
  , AST_LOGICAL_OR
  , AST_LOGICAL_XOR

  , AST_RELATIONAL_EQ
  , AST_RELATIONAL_GEQ
  , AST_RELATIONAL_GT
  , AST_RELATIONAL_LEQ
  , AST_RELATIONAL_LT
  , AST_RELATIONAL_NEQ

  , AST_UNKNOWN
} ASTNodeType_t;
# 61 "../../math/ASTNode.h" 2
# 71 "../../math/ASTNode.h"
typedef int (*ASTNodePredicate) (const ASTNode_t *node);
# 541 "../../math/ASTNode.h"









ASTNode_t *
ASTNode_create (void);




ASTNode_t *
ASTNode_createWithType (ASTNodeType_t type);





ASTNode_t *
ASTNode_createFromToken (Token_t *token);






void
ASTNode_free (ASTNode_t *node);





void
ASTNode_freeName (ASTNode_t *node);
# 609 "../../math/ASTNode.h"

int
ASTNode_canonicalize (ASTNode_t *node);







void
ASTNode_addChild (ASTNode_t *node, ASTNode_t *child);






void
ASTNode_prependChild (ASTNode_t *node, ASTNode_t *child);






ASTNode_t *
ASTNode_deepCopy (const ASTNode_t *node);







ASTNode_t *
ASTNode_getChild (const ASTNode_t *node, unsigned int n);






ASTNode_t *
ASTNode_getLeftChild (const ASTNode_t *node);
# 662 "../../math/ASTNode.h"

ASTNode_t *
ASTNode_getRightChild (const ASTNode_t *node);






unsigned int
ASTNode_getNumChildren (const ASTNode_t *node);
# 691 "../../math/ASTNode.h"

List_t *
ASTNode_getListOfNodes (ASTNode_t *node, ASTNodePredicate predicate);






void
ASTNode_fillListOfNodes ( ASTNode_t *node,
                          ASTNodePredicate predicate,
                          List_t *lst );








char
ASTNode_getCharacter (const ASTNode_t *node);






long
ASTNode_getInteger (const ASTNode_t *node);







const char *
ASTNode_getName (const ASTNode_t *node);






long
ASTNode_getNumerator (const ASTNode_t *node);






long
ASTNode_getDenominator (const ASTNode_t *node);
# 756 "../../math/ASTNode.h"

double
ASTNode_getReal (const ASTNode_t *node);







double
ASTNode_getMantissa (const ASTNode_t *node);






long
ASTNode_getExponent (const ASTNode_t *node);






int
ASTNode_getPrecedence (const ASTNode_t *node);





ASTNodeType_t
ASTNode_getType (const ASTNode_t *node);







int
ASTNode_isBoolean (const ASTNode_t *node);






int
ASTNode_isConstant (const ASTNode_t *node);







int
ASTNode_isFunction (const ASTNode_t *node);






int
ASTNode_isInteger (const ASTNode_t *node);






int
ASTNode_isLambda (const ASTNode_t *node);
# 841 "../../math/ASTNode.h"

int
ASTNode_isLog10 (const ASTNode_t *node);






int
ASTNode_isLogical (const ASTNode_t *node);







int
ASTNode_isName (const ASTNode_t *node);
# 870 "../../math/ASTNode.h"

int
ASTNode_isNumber (const ASTNode_t *node);






int
ASTNode_isOperator (const ASTNode_t *node);






int
ASTNode_isRational (const ASTNode_t *node);
# 897 "../../math/ASTNode.h"

int
ASTNode_isReal (const ASTNode_t *node);






int
ASTNode_isRelational (const ASTNode_t *node);
# 916 "../../math/ASTNode.h"

int
ASTNode_isSqrt (const ASTNode_t *node);
# 932 "../../math/ASTNode.h"

int
ASTNode_isUMinus (const ASTNode_t *node);






int
ASTNode_isUnknown (const ASTNode_t *node);








void
ASTNode_setCharacter (ASTNode_t *node, char value);
# 962 "../../math/ASTNode.h"

void
ASTNode_setName (ASTNode_t *node, const char *name);






void
ASTNode_setInteger (ASTNode_t *node, long value);






void
ASTNode_setRational (ASTNode_t *node, long numerator, long denominator);
# 990 "../../math/ASTNode.h"

void
ASTNode_setReal (ASTNode_t *node, double value);






void
ASTNode_setRealWithExponent (ASTNode_t *node, double mantissa, long exponent);





void
ASTNode_setType (ASTNode_t *node, ASTNodeType_t type);






void
ASTNode_swapChildren (ASTNode_t *node, ASTNode_t *that);



# 60 "../../math/FormulaParser.h" 2




# 72 "../../math/FormulaParser.h"

ASTNode_t *
SBML_parseFormula (const char *formula);
# 88 "../../math/FormulaParser.h"
long
FormulaParser_getAction (long state, Token_t *token);







long
FormulaParser_getActionLength (TokenType_t type);







long
FormulaParser_getActionOffset (TokenType_t type);






long
FormulaParser_getGoto (long state, long rule);





ASTNode_t *
FormulaParser_reduceStackByRule (Stack_t *stack, long rule);



# 52 "sbmllisp.h" 2
# 1 "../../math/FormulaFormatter.h" 1
# 57 "../../math/FormulaFormatter.h"
# 1 "../../math/../util/StringBuffer.h" 1
# 54 "../../math/../util/StringBuffer.h"
# 1 "../../math/../util/../common/extern.h" 1
# 55 "../../math/../util/StringBuffer.h" 2





typedef struct
{
  unsigned long length;
  unsigned long capacity;

  char *buffer;
} StringBuffer_t;






StringBuffer_t *
StringBuffer_create (unsigned long capacity);





void
StringBuffer_free (StringBuffer_t *sb);






void
StringBuffer_reset (StringBuffer_t *sb);





void
StringBuffer_append (StringBuffer_t *sb, const char *s);





void
StringBuffer_appendChar (StringBuffer_t *sb, char c);
# 114 "../../math/../util/StringBuffer.h"

void
StringBuffer_appendNumber (StringBuffer_t *sb, const char *format, ...);
# 126 "../../math/../util/StringBuffer.h"

void
StringBuffer_appendInt (StringBuffer_t *sb, long i);
# 138 "../../math/../util/StringBuffer.h"

void
StringBuffer_appendReal (StringBuffer_t *sb, double r);
# 151 "../../math/../util/StringBuffer.h"

void
StringBuffer_ensureCapacity (StringBuffer_t *sb, unsigned long n);
# 163 "../../math/../util/StringBuffer.h"

void
StringBuffer_grow (StringBuffer_t *sb, unsigned long n);
# 184 "../../math/../util/StringBuffer.h"

char *
StringBuffer_getBuffer (const StringBuffer_t *sb);





unsigned long
StringBuffer_length (const StringBuffer_t *sb);






unsigned long
StringBuffer_capacity (const StringBuffer_t *sb);







char *
StringBuffer_toString (const StringBuffer_t *sb);



# 58 "../../math/FormulaFormatter.h" 2












char *
SBML_formulaToString (const ASTNode_t *tree);
# 81 "../../math/FormulaFormatter.h"
int
FormulaFormatter_isFunction (const ASTNode_t *node);
# 97 "../../math/FormulaFormatter.h"
int
FormulaFormatter_isGrouped (const ASTNode_t *parent, const ASTNode_t *child);





void
FormulaFormatter_format (StringBuffer_t *sb, const ASTNode_t *node);





void
FormulaFormatter_formatFunction (StringBuffer_t *sb, const ASTNode_t *node);





void
FormulaFormatter_formatOperator (StringBuffer_t *sb, const ASTNode_t *node);







void
FormulaFormatter_formatRational (StringBuffer_t *sb, const ASTNode_t *node);





void
FormulaFormatter_formatReal (StringBuffer_t *sb, const ASTNode_t *node);






void
FormulaFormatter_visit ( const ASTNode_t *parent,
                         const ASTNode_t *node,
                         StringBuffer_t *sb );





void
FormulaFormatter_visitFunction ( const ASTNode_t *parent,
                                 const ASTNode_t *node,
                                 StringBuffer_t *sb );





void
FormulaFormatter_visitLog10 ( const ASTNode_t *parent,
                              const ASTNode_t *node,
                              StringBuffer_t *sb );





void
FormulaFormatter_visitSqrt ( const ASTNode_t *parent,
                             const ASTNode_t *node,
                             StringBuffer_t *sb );





void
FormulaFormatter_visitUMinus ( const ASTNode_t *parent,
                               const ASTNode_t *node,
                               StringBuffer_t *sb );




void
FormulaFormatter_visitOther ( const ASTNode_t *parent,
                              const ASTNode_t *node,
                              StringBuffer_t *sb );



# 52 "sbmllisp.h" 2
