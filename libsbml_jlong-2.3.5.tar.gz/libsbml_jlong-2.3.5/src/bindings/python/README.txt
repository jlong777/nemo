For a quick tutorial on the Python binding, look in
$LIBSBMLHOME/docs/formatted/python.txt.
