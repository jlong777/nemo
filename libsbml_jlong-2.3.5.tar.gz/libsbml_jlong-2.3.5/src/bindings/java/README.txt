For a quick tutorial on the Java binding, look in
$LIBSBMLHOME/docs/formatted/java.txt.
